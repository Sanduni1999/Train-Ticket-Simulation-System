package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class Main extends Application {

    //Here i have used private static final data structure(arrayLists) to store user(customer) details.

    static final int SEATING_CAPACITY = 42;

    private static final ArrayList<String> userDetails1 = new ArrayList<>();
    private static final ArrayList<String> userDetails2 = new ArrayList<>();
    private static final ArrayList<String> userDetails3 = new ArrayList<>();
    private static final ArrayList<String> userDetails4 = new ArrayList<>();
    private static final ArrayList<String> userDetails5 = new ArrayList<>();
    private static final ArrayList<String> userDetails6 = new ArrayList<>();
    private static final ArrayList<String> userDetails7 = new ArrayList<>();
    private static final ArrayList<String> userDetails8 = new ArrayList<>();
    private static final ArrayList<String> userDetails9 = new ArrayList<>();
    private static final ArrayList<String> userDetails10 = new ArrayList<>();
    private static final ArrayList<String> userDetails11 = new ArrayList<>();
    private static final ArrayList<String> userDetails12 = new ArrayList<>();
    private static final ArrayList<String> userDetails13 = new ArrayList<>();
    private static final ArrayList<String> userDetails14 = new ArrayList<>();
    private static final ArrayList<String> userDetails15= new ArrayList<>();
    private static final ArrayList<String> userDetails16= new ArrayList<>();
    private static final ArrayList<String> userDetails17= new ArrayList<>();
    private static final ArrayList<String> userDetails18 = new ArrayList<>();
    private static final ArrayList<String> userDetails19 = new ArrayList<>();
    private static final ArrayList<String> userDetails20 = new ArrayList<>();
    private static final ArrayList<String> userDetails21 = new ArrayList<>();
    private static final ArrayList<String> userDetails22 = new ArrayList<>();
    private static final ArrayList<String> userDetails23 = new ArrayList<>();
    private static final ArrayList<String> userDetails24 = new ArrayList<>();
    private static final ArrayList<String> userDetails25 = new ArrayList<>();
    private static final ArrayList<String> userDetails26= new ArrayList<>();
    private static final ArrayList<String> userDetails27 = new ArrayList<>();
    private static final ArrayList<String> userDetails28 = new ArrayList<>();
    private static final ArrayList<String> userDetails29 = new ArrayList<>();
    private static final ArrayList<String> userDetails30= new ArrayList<>();
    private static final ArrayList<String> userDetails31 = new ArrayList<>();
    private static final ArrayList<String> userDetails32 = new ArrayList<>();
    private static final ArrayList<String> userDetails33 = new ArrayList<>();
    private static final ArrayList<String> userDetails34 = new ArrayList<>();
    private static final ArrayList<String> userDetails35 = new ArrayList<>();
    private static final ArrayList<String> userDetails36 = new ArrayList<>();
    private static final ArrayList<String> userDetails37 = new ArrayList<>();
    private static final ArrayList<String> userDetails38 = new ArrayList<>();
    private static final ArrayList<String> userDetails39 = new ArrayList<>();
    private static final ArrayList<String> userDetails40 = new ArrayList<>();
    private static final ArrayList<String> userDetails41 = new ArrayList<>();
    private static final ArrayList<String> userDetails42 = new ArrayList<>();
    private static final ArrayList<String> allNames = new ArrayList<>();
    private static final ArrayList<String> allNIC = new ArrayList<>();

    private static String userName;
    private static String userNIC;


    @Override
    public void start(Stage primaryStage) throws Exception {

        ArrayList<String> btnList = new ArrayList<>();     //this array list is for buttons
        menu(btnList);      //here i am calling the menu method first. Menu method has all the options.
    }

    public static void menu(ArrayList<String> btnList) throws IOException {

        System.out.println("Welcome!  Take the Denuwara Menike Train and visit Sri Lanka.");
        Scanner sc = new Scanner(System.in);

        System.out.println("A = add a customer to a seat");
        System.out.println("V = View All Seats");
        System.out.println("E = View Empty Seats");
        System.out.println("D = Delete a Booked Seat");
        System.out.println("F = Find a seat by a customer name");
        System.out.println("0 = View seats ordered by customer name");
        System.out.println("S = Store Program data into file");
        System.out.println("Q = Quit");

        String  userOption;

        System.out.print("Enter your prefer option:");
        userOption = sc.nextLine();

        System.out.print("Enter your name:");
        userName = sc.nextLine();
        allNames.add(userName);

        System.out.print("Enter your NIC number:");
        userNIC = sc.nextLine();


//            menu:
        switch (userOption) {
            case "A":
            case "a":

                add_customer(btnList);
                break;

            case "V":
            case "v":

                view_seats(btnList);
                break;

            case "E":
            case "e":

                empty_seats(btnList);
                break;

            case "D":
            case "d":

                delete_seat(btnList);
                break;

            case "F":
            case "f":
                find_seats(btnList);
                break;

            case "Q":
            case "q":
                quit();
                break;

            case "S":
            case "s":
                store(btnList);
                break;

            case "L":
            case "l":
                load();
                break;

            case "O":
            case "0":
                order(btnList);
                break;

            default:
                System.out.println("Invalid. Please try again");
        }

    }


    public static void add_customer(ArrayList<String> btnList) throws IOException {

        Stage primaryStage = new Stage();
        primaryStage.setTitle("Train Booking System");

        FlowPane fPane=new FlowPane(Orientation.HORIZONTAL,40,40); //to give a space between buttons

        //to add space around the pane
        fPane.setPadding(new Insets(20));

        Button seat1;
        Button seat2;
        Button seat3;
        Button seat4;
        Button seat5;
        Button seat6;
        Button seat7;
        Button seat8;
        Button seat9;
        Button seat10;
        Button seat11;
        Button seat12;
        Button seat13;
        Button seat14;
        Button seat15;
        Button seat16;
        Button seat17;
        Button seat18;
        Button seat19;
        Button seat20;
        Button seat21;
        Button seat22;
        Button seat23;
        Button seat24;
        Button seat25;
        Button seat26;
        Button seat27;
        Button seat28;
        Button seat29;
        Button seat30;
        Button seat31;
        Button seat32;
        Button seat33;
        Button seat34;
        Button seat35;
        Button seat36;
        Button seat37;
        Button seat38;
        Button seat39;
        Button seat40;
        Button seat41;
        Button seat42;


        seat1=new Button();
        seat1.setText("seat 1");
        seat2=new Button();
        seat2.setText("seat 2");
        seat3=new Button();
        seat3.setText("seat 3");
        seat4=new Button();
        seat4.setText("seat 4");
        seat5=new Button();
        seat5.setText("seat 5");
        seat6=new Button();
        seat6.setText("seat 6");
        seat7=new Button();
        seat7.setText("seat 7");
        seat8=new Button();
        seat8.setText("seat 8");
        seat9=new Button();
        seat9.setText("seat 9");
        seat10=new Button();
        seat10.setText("seat 10");
        seat11=new Button();
        seat11.setText("seat 11");
        seat12=new Button();
        seat12.setText("seat 12");
        seat13=new Button();
        seat13.setText("seat 13");
        seat14=new Button();
        seat14.setText("seat 14");
        seat15=new Button();
        seat15.setText("seat 15");
        seat16=new Button();
        seat16.setText("seat 16");
        seat17=new Button();
        seat17.setText("seat 17");
        seat18=new Button();
        seat18.setText("seat 18");
        seat19=new Button();
        seat19.setText("seat 19");
        seat20=new Button();
        seat20.setText("seat 20");
        seat21=new Button();
        seat21.setText("seat 21");
        seat22=new Button();
        seat22.setText("seat 22");
        seat23=new Button();
        seat23.setText("seat 23");
        seat24=new Button();
        seat24.setText("seat 24");
        seat25=new Button();
        seat25.setText("seat 25");
        seat26=new Button();
        seat26.setText("seat 26");
        seat27=new Button();
        seat27.setText("seat 27");
        seat28=new Button();
        seat28.setText("seat 28");
        seat29=new Button();
        seat29.setText("seat 29");
        seat30=new Button();
        seat30.setText("seat 30");
        seat31=new Button();
        seat31.setText("seat 31");
        seat32=new Button();
        seat32.setText("seat 32");
        seat33=new Button();
        seat33.setText("seat 33");
        seat34=new Button();
        seat34.setText("seat 34");
        seat35=new Button();
        seat35.setText("seat 35");
        seat36=new Button();
        seat36.setText("seat 36");
        seat37=new Button();
        seat37.setText("seat 37");
        seat38=new Button();
        seat38.setText("seat 38");
        seat39=new Button();
        seat39.setText("seat 39");
        seat40=new Button();
        seat40.setText("seat 40");
        seat41=new Button();
        seat41.setText("seat 41");
        seat42=new Button();
        seat42.setText("seat 42");


        fPane.getChildren().add(seat1);
        fPane.getChildren().add(seat2);
        fPane.getChildren().add(seat3);
        fPane.getChildren().add(seat4);
        fPane.getChildren().add(seat5);
        fPane.getChildren().add(seat6);
        fPane.getChildren().add(seat7);
        fPane.getChildren().add(seat8);
        fPane.getChildren().add(seat9);
        fPane.getChildren().add(seat10);
        fPane.getChildren().add(seat11);
        fPane.getChildren().add(seat12);
        fPane.getChildren().add(seat13);
        fPane.getChildren().add(seat14);
        fPane.getChildren().add(seat15);
        fPane.getChildren().add(seat16);
        fPane.getChildren().add(seat17);
        fPane.getChildren().add(seat18);
        fPane.getChildren().add(seat19);
        fPane.getChildren().add(seat20);
        fPane.getChildren().add(seat21);
        fPane.getChildren().add(seat22);
        fPane.getChildren().add(seat23);
        fPane.getChildren().add(seat24);
        fPane.getChildren().add(seat25);
        fPane.getChildren().add(seat26);
        fPane.getChildren().add(seat27);
        fPane.getChildren().add(seat28);
        fPane.getChildren().add(seat29);
        fPane.getChildren().add(seat30);
        fPane.getChildren().add(seat31);
        fPane.getChildren().add(seat32);
        fPane.getChildren().add(seat33);
        fPane.getChildren().add(seat34);
        fPane.getChildren().add(seat35);
        fPane.getChildren().add(seat36);
        fPane.getChildren().add(seat37);
        fPane.getChildren().add(seat38);
        fPane.getChildren().add(seat39);
        fPane.getChildren().add(seat40);
        fPane.getChildren().add(seat41);
        fPane.getChildren().add(seat42);

        Scene scene=new Scene(fPane,500,900);

        primaryStage.setScene(scene);
        primaryStage.show();


        seat1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat1.setStyle("-fx-background-color: Yellow");
                btnList.add(seat1.getText());
                userDetails1.add(userName);             //appending user deatils to arralists for future use
                userDetails1.add(userNIC);
                userDetails1.add(seat1.getText());
            }
        });
        seat2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat2.setStyle("-fx-background-color: Yellow");
                btnList.add(seat2.getText());
                userDetails2.add(userName);
                userDetails2.add(userNIC);
                userDetails2.add(seat2.getText());
            }
        });
        seat3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat3.setStyle("-fx-background-color: Yellow");
                btnList.add(seat3.getText());
                userDetails3.add(userName);
                userDetails3.add(userNIC);
                userDetails3.add(seat3.getText());
            }
        });
        seat4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat4.setStyle("-fx-background-color: Yellow");
                btnList.add(seat4.getText());
                userDetails4.add(userName);
                userDetails4.add(userNIC);
                userDetails4.add(seat4.getText());
            }
        });
        seat5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat5.setStyle("-fx-background-color: Yellow");
                btnList.add(seat5.getText());
                userDetails5.add(userName);
                userDetails5.add(userNIC);
                userDetails5.add(seat5.getText());
            }
        });
        seat6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat6.setStyle("-fx-background-color: Yellow");
                btnList.add(seat6.getText());
                userDetails6.add(userName);
                userDetails6.add(userNIC);
                userDetails6.add(seat6.getText());
            }
        });
        seat7.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat7.setStyle("-fx-background-color: Yellow");
                btnList.add(seat7.getText());
                userDetails7.add(userName);
                userDetails7.add(userNIC);
                userDetails7.add(seat7.getText());
            }
        });
        seat8.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat8.setStyle("-fx-background-color: Yellow");
                btnList.add(seat8.getText());
                userDetails8.add(userName);
                userDetails8.add(userNIC);
                userDetails8.add(seat8.getText());
            }
        });
        seat9.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat9.setStyle("-fx-background-color: Yellow");
                btnList.add(seat9.getText());
                userDetails9.add(userName);
                userDetails9.add(userNIC);
                userDetails9.add(seat9.getText());
            }
        });
        seat10.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat10.setStyle("-fx-background-color: Yellow");
                btnList.add(seat10.getText());
                userDetails10.add(userName);
                userDetails10.add(userNIC);
                userDetails10.add(seat10.getText());
            }
        });
        seat11.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat11.setStyle("-fx-background-color: Yellow");
                btnList.add(seat11.getText());
                userDetails11.add(userName);
                userDetails11.add(userNIC);
                userDetails11.add(seat11.getText());
            }
        });
        seat12.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat12.setStyle("-fx-background-color: Yellow");
                btnList.add(seat12.getText());
                userDetails12.add(userName);
                userDetails12.add(userNIC);
                userDetails12.add(seat12.getText());
            }
        });
        seat13.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat13.setStyle("-fx-background-color: Yellow");
                btnList.add(seat13.getText());
                userDetails13.add(userName);
                userDetails13.add(userNIC);
                userDetails13.add(seat13.getText());
            }
        });
        seat14.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat14.setStyle("-fx-background-color: Yellow");
                btnList.add(seat14.getText());
                userDetails14.add(userName);
                userDetails14.add(userNIC);
                userDetails14.add(seat14.getText());
            }
        });
        seat15.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat15.setStyle("-fx-background-color: Yellow");
                btnList.add(seat15.getText());
                userDetails15.add(userName);
                userDetails15.add(userNIC);
                userDetails15.add(seat15.getText());
            }
        });
        seat16.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat16.setStyle("-fx-background-color: Yellow");
                btnList.add(seat16.getText());
                userDetails16.add(userName);
                userDetails16.add(userNIC);
                userDetails16.add(seat16.getText());
            }
        });
        seat17.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat17.setStyle("-fx-background-color: Yellow");
                btnList.add(seat17.getText());
                userDetails17.add(userName);
                userDetails17.add(userNIC);
                userDetails17.add(seat17.getText());
            }
        });
        seat18.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat18.setStyle("-fx-background-color: Yellow");
                btnList.add(seat18.getText());
                userDetails18.add(userName);
                userDetails18.add(userNIC);
                userDetails18.add(seat18.getText());
            }
        });
        seat19.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat19.setStyle("-fx-background-color: Yellow");
                btnList.add(seat19.getText());
                userDetails19.add(userName);
                userDetails19.add(userNIC);
                userDetails19.add(seat19.getText());
            }
        });
        seat20.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat20.setStyle("-fx-background-color: Yellow");
                btnList.add(seat20.getText());
                userDetails20.add(userName);
                userDetails20.add(userNIC);
                userDetails20.add(seat20.getText());
            }
        });
        seat21.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat21.setStyle("-fx-background-color: Yellow");
                btnList.add(seat21.getText());
                userDetails21.add(userName);
                userDetails21.add(userNIC);
                userDetails21.add(seat21.getText());
            }
        });
        seat22.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat22.setStyle("-fx-background-color: Yellow");
                btnList.add(seat22.getText());
                userDetails22.add(userName);
                userDetails22.add(userNIC);
                userDetails21.add(seat21.getText());
            }
        });
        seat23.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat23.setStyle("-fx-background-color: Yellow");
                btnList.add(seat23.getText());
                userDetails23.add(userName);
                userDetails23.add(userNIC);
                userDetails23.add(seat23.getText());
            }

        });
        seat24.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat24.setStyle("-fx-background-color: Yellow");
                btnList.add(seat24.getText());
                userDetails24.add(userName);
                userDetails24.add(userNIC);
                userDetails24.add(seat24.getText());
            }
        });
        seat25.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat25.setStyle("-fx-background-color: Yellow");
                btnList.add(seat25.getText());
                userDetails25.add(userName);
                userDetails25.add(userNIC);
                userDetails25.add(seat25.getText());
            }
        });
        seat26.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat26.setStyle("-fx-background-color: Yellow");
                btnList.add(seat26.getText());
                userDetails26.add(userName);
                userDetails26.add(userNIC);
                userDetails26.add(seat26.getText());
            }
        });
        seat27.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat27.setStyle("-fx-background-color: Yellow");
                btnList.add(seat27.getText());
                userDetails27.add(userName);
                userDetails27.add(userNIC);
                userDetails27.add(seat27.getText());
            }
        });
        seat28.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat28.setStyle("-fx-background-color: Yellow");
                btnList.add(seat28.getText());
                userDetails28.add(userName);
                userDetails28.add(userNIC);
                userDetails28.add(seat28.getText());
            }
        });
        seat29.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat29.setStyle("-fx-background-color: Yellow");
                btnList.add(seat29.getText());
                userDetails29.add(userName);
                userDetails29.add(userNIC);
                userDetails29.add(seat29.getText());
            }
        });
        seat30.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat30.setStyle("-fx-background-color: Yellow");
                btnList.add(seat30.getText());
                userDetails30.add(userName);
                userDetails30.add(userNIC);
                userDetails30.add(seat30.getText());
            }
        });
        seat31.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat31.setStyle("-fx-background-color: Yellow");
                btnList.add(seat31.getText());
                userDetails31.add(userName);
                userDetails31.add(userNIC);
                userDetails31.add(seat31.getText());
            }
        });
        seat32.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat32.setStyle("-fx-background-color: Yellow");
                btnList.add(seat32.getText());
                userDetails32.add(userName);
                userDetails32.add(userNIC);
                userDetails32.add(seat32.getText());
            }
        });
        seat33.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat33.setStyle("-fx-background-color: Yellow");
                btnList.add(seat33.getText());
                userDetails33.add(userName);
                userDetails33.add(userNIC);
                userDetails33.add(seat33.getText());
            }
        });
        seat34.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat34.setStyle("-fx-background-color: Yellow");
                btnList.add(seat34.getText());
                userDetails34.add(userName);
                userDetails34.add(userNIC);
                userDetails34.add(seat34.getText());
            }
        });
        seat35.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat35.setStyle("-fx-background-color: Yellow");
                btnList.add(seat35.getText());
                userDetails35.add(userName);
                userDetails35.add(userNIC);
                userDetails35.add(seat35.getText());
            }
        });
        seat36.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat36.setStyle("-fx-background-color: Yellow");
                btnList.add(seat36.getText());
                userDetails36.add(userName);
                userDetails36.add(userNIC);
                userDetails36.add(seat36.getText());
            }
        });
        seat37.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat37.setStyle("-fx-background-color: Yellow");
                btnList.add(seat37.getText());
                userDetails37.add(userName);
                userDetails37.add(userNIC);
                userDetails37.add(seat37.getText());
            }
        });
        seat38.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat38.setStyle("-fx-background-color: Yellow");
                btnList.add(seat38.getText());
                userDetails38.add(userName);
                userDetails38.add(userNIC);
                userDetails38.add(seat38.getText());
            }
        });
        seat39.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat39.setStyle("-fx-background-color: Yellow");
                btnList.add(seat39.getText());
                userDetails39.add(userName);
                userDetails39.add(userNIC);
                userDetails39.add(seat39.getText());
            }
        });
        seat40.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat40.setStyle("-fx-background-color: Yellow");
                btnList.add(seat40.getText());
                userDetails40.add(userName);
                userDetails40.add(userNIC);
                userDetails40.add(seat40.getText());
            }
        });
        seat41.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat41.setStyle("-fx-background-color: Yellow");
                btnList.add(seat41.getText());
                userDetails41.add(userName);
                userDetails41.add(userNIC);
                userDetails41.add(seat41.getText());
            }

        });
        seat42.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                seat42.setStyle("-fx-background-color: Yellow");
                btnList.add(seat42.getText());
                userDetails42.add(userName);
                userDetails42.add(userNIC);
                userDetails42.add(seat42.getText());
            }
        });

        if (btnList.contains(seat1.getText())){         //booked seats are disable because 1 seat is for 1 customer only
            seat1.setDisable(true);
        }
        if (btnList.contains(seat2.getText())){
            seat2.setDisable(true);
        }
        if (btnList.contains(seat3.getText())){
            seat3.setDisable(true);
        }
        if (btnList.contains(seat4.getText())){
            seat4.setDisable(true);
        }
        if (btnList.contains(seat5.getText())){
            seat5.setDisable(true);
        }
        if (btnList.contains(seat6.getText())){
            seat6.setDisable(true);
        }
        if (btnList.contains(seat7.getText())){
            seat7.setDisable(true);
        }
        if (btnList.contains(seat8.getText())){
            seat8.setDisable(true);
        }
        if (btnList.contains(seat9.getText())){
            seat9.setDisable(true);
        }

        if (btnList.contains(seat10.getText())){
            seat10.setDisable(true);
        }
        if (btnList.contains(seat11.getText())){
            seat11.setDisable(true);
        }
        if (btnList.contains(seat12.getText())){
            seat12.setDisable(true);
        }
        if (btnList.contains(seat13.getText())){
            seat13.setDisable(true);
        }
        if (btnList.contains(seat14.getText())){
            seat14.setDisable(true);
        }
        if (btnList.contains(seat15.getText())){
            seat15.setDisable(true);
        }
        if (btnList.contains(seat16.getText())){
            seat16.setDisable(true);
        }
        if (btnList.contains(seat17.getText())){
            seat17.setDisable(true);
        }
        if (btnList.contains(seat18.getText())){
            seat18.setDisable(true);
        }
        if (btnList.contains(seat19.getText())){
            seat19.setDisable(true);
        }
        if (btnList.contains(seat20.getText())){
            seat20.setDisable(true);
        }
        if (btnList.contains(seat21.getText())){
            seat21.setDisable(true);
        }
        if (btnList.contains(seat22.getText())){
            seat22.setDisable(true);
        }
        if (btnList.contains(seat23.getText())){
            seat23.setDisable(true);
        }
        if (btnList.contains(seat24.getText())){
            seat24.setDisable(true);
        }
        if (btnList.contains(seat25.getText())){
            seat25.setDisable(true);
        }
        if (btnList.contains(seat26.getText())){
            seat26.setDisable(true);
        }
        if (btnList.contains(seat27.getText())){
            seat27.setDisable(true);
        }
        if (btnList.contains(seat28.getText())){
            seat28.setDisable(true);
        }
        if (btnList.contains(seat29.getText())){
            seat29.setDisable(true);
        }
        if (btnList.contains(seat30.getText())){
            seat30.setDisable(true);
        }
        if (btnList.contains(seat31.getText())){
            seat31.setDisable(true);
        }
        if (btnList.contains(seat32.getText())){
            seat32.setDisable(true);
        }
        if (btnList.contains(seat33.getText())){
            seat33.setDisable(true);
        }
        if (btnList.contains(seat34.getText())){
            seat34.setDisable(true);
        }
        if (btnList.contains(seat35.getText())){
            seat35.setDisable(true);
        }
        if (btnList.contains(seat36.getText())){
            seat36.setDisable(true);
        }
        if (btnList.contains(seat37.getText())){
            seat37.setDisable(true);
        }
        if (btnList.contains(seat38.getText())){
            seat38.setDisable(true);
        }
        if (btnList.contains(seat39.getText())){
            seat39.setDisable(true);
        }
        if (btnList.contains(seat40.getText())){
            seat40.setDisable(true);
        }
        if (btnList.contains(seat41.getText())){
            seat41.setDisable(true);
        }
        if (btnList.contains(seat42.getText())){
            seat42.setDisable(true);
        }

        /*i put a button to go back to the options. so that users can use any option again and again if they want.If they
        want to exit the from the program they choose Q option.
        */

        Button btnMenu;
        btnMenu=new Button();
        btnMenu.setText("Back to options");
        fPane.getChildren().add(btnMenu);

        btnMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    menu(btnList);
                    primaryStage.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void view_seats(ArrayList<String> btnList) throws IOException {
        Stage primaryStage = new Stage();
        primaryStage.setTitle("Train Booking System");

        FlowPane fPane=new FlowPane(Orientation.HORIZONTAL,40,40); //to give space between buttons

        //to add space around the pane
        fPane.setPadding(new Insets(20));

        Button seat1;
        Button seat2;
        Button seat3;
        Button seat4;
        Button seat5;
        Button seat6;
        Button seat7;
        Button seat8;
        Button seat9;
        Button seat10;
        Button seat11;
        Button seat12;
        Button seat13;
        Button seat14;
        Button seat15;
        Button seat16;
        Button seat17;
        Button seat18;
        Button seat19;
        Button seat20;
        Button seat21;
        Button seat22;
        Button seat23;
        Button seat24;
        Button seat25;
        Button seat26;
        Button seat27;
        Button seat28;
        Button seat29;
        Button seat30;
        Button seat31;
        Button seat32;
        Button seat33;
        Button seat34;
        Button seat35;
        Button seat36;
        Button seat37;
        Button seat38;
        Button seat39;
        Button seat40;
        Button seat41;
        Button seat42;


        seat1=new Button("seat 1");
        seat2=new Button("seat 2");
        seat3=new Button("seat 3");
        seat4=new Button("seat 4");
        seat5=new Button("seat 5");
        seat6=new Button("seat 6");
        seat7=new Button("seat 7");
        seat8=new Button("seat 8");
        seat9=new Button("seat 9");
        seat10=new Button("seat 10");
        seat11=new Button("seat 11");
        seat12=new Button("seat 12");
        seat13=new Button("seat 13");
        seat14=new Button("seat 14");
        seat15=new Button("seat 15");
        seat16=new Button("seat 16");
        seat17=new Button("seat 17");
        seat18=new Button("seat 18");
        seat19=new Button("seat 19");
        seat20=new Button("seat 20");
        seat21=new Button("seat 21");
        seat22=new Button("seat 22");
        seat23=new Button("seat 23");
        seat24=new Button("seat 24");
        seat25=new Button("seat 25");
        seat26=new Button("seat 26");
        seat27=new Button("seat 27");
        seat28=new Button("seat 28");
        seat29=new Button("seat 29");
        seat30=new Button("seat 30");
        seat31=new Button("seat 31");
        seat32=new Button("seat 32");
        seat33=new Button("seat 33");
        seat34=new Button("seat 34");
        seat35=new Button("seat 35");
        seat36=new Button("seat 36");
        seat37=new Button("seat 37");
        seat38=new Button("seat 38");
        seat39=new Button("seat 39");
        seat40=new Button("seat 40");
        seat41=new Button("seat 41");
        seat42=new Button("seat 42");


        Label label1=new Label();
        label1.setText("Pink colour seats are already booked");
        fPane.getChildren().add(label1);

        fPane.getChildren().add(seat1);
        fPane.getChildren().add(seat2);
        fPane.getChildren().add(seat3);
        fPane.getChildren().add(seat4);
        fPane.getChildren().add(seat5);
        fPane.getChildren().add(seat6);
        fPane.getChildren().add(seat7);
        fPane.getChildren().add(seat8);
        fPane.getChildren().add(seat9);
        fPane.getChildren().add(seat10);
        fPane.getChildren().add(seat11);
        fPane.getChildren().add(seat12);
        fPane.getChildren().add(seat13);
        fPane.getChildren().add(seat14);
        fPane.getChildren().add(seat15);
        fPane.getChildren().add(seat16);
        fPane.getChildren().add(seat17);
        fPane.getChildren().add(seat18);
        fPane.getChildren().add(seat19);
        fPane.getChildren().add(seat20);
        fPane.getChildren().add(seat21);
        fPane.getChildren().add(seat22);
        fPane.getChildren().add(seat23);
        fPane.getChildren().add(seat24);
        fPane.getChildren().add(seat25);
        fPane.getChildren().add(seat26);
        fPane.getChildren().add(seat27);
        fPane.getChildren().add(seat28);
        fPane.getChildren().add(seat29);
        fPane.getChildren().add(seat30);
        fPane.getChildren().add(seat31);
        fPane.getChildren().add(seat32);
        fPane.getChildren().add(seat33);
        fPane.getChildren().add(seat34);
        fPane.getChildren().add(seat35);
        fPane.getChildren().add(seat36);
        fPane.getChildren().add(seat37);
        fPane.getChildren().add(seat38);
        fPane.getChildren().add(seat39);
        fPane.getChildren().add(seat40);
        fPane.getChildren().add(seat41);
        fPane.getChildren().add(seat42);

        Scene scene=new Scene(fPane,500,900);


        primaryStage.setScene(scene);
        primaryStage.show();

        //Here booked seats are in pink.
        /*if someone has booked a seat(if someone has clicked the button), that text of the button goes to the
        btnList.
        */

        if (btnList.contains(seat1.getText())){
            seat1.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat2.getText())){
            seat2.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat3.getText())){
            seat3.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat4.getText())){
            seat4.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat5.getText())){
            seat5.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat6.getText())){
            seat6.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat7.getText())){
            seat7.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat8.getText())){
            seat8.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat9.getText())){
            seat9.setStyle("-fx-background-color: Pink");
        }

        if (btnList.contains(seat10.getText())){
            seat10.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat11.getText())){
            seat11.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat12.getText())){
            seat12.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat13.getText())){
            seat13.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat14.getText())){
            seat14.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat15.getText())){
            seat15.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat16.getText())){
            seat16.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat17.getText())){
            seat17.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat18.getText())){
            seat18.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat19.getText())){
            seat19.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat20.getText())){
            seat20.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat21.getText())){
            seat21.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat22.getText())){
            seat22.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat23.getText())){
            seat23.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat24.getText())){
            seat24.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat25.getText())){
            seat25.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat26.getText())){
            seat26.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat27.getText())){
            seat27.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat28.getText())){
            seat28.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat29.getText())){
            seat29.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat30.getText())){
            seat30.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat31.getText())){
            seat31.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat32.getText())){
            seat32.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat33.getText())){
            seat33.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat34.getText())){
            seat34.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat35.getText())){
            seat35.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat36.getText())){
            seat36.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat37.getText())){
            seat37.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat38.getText())){
            seat38.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat39.getText())){
            seat39.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat40.getText())){
            seat40.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat41.getText())){
            seat41.setStyle("-fx-background-color: Pink");
        }
        if (btnList.contains(seat42.getText())){
            seat42.setStyle("-fx-background-color: Pink");
        }

        Button btnMenu;
        btnMenu=new Button();
        btnMenu.setText("Back to options");
        fPane.getChildren().add(btnMenu);

        btnMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    menu(btnList);
                    primaryStage.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public static void empty_seats(ArrayList<String> btnList) {

        //Here you can only the empty seats.
        //other seats are not visible.

        Stage primaryStage = new Stage();
        primaryStage.setTitle("Train Booking System");

        FlowPane fPane=new FlowPane(Orientation.HORIZONTAL,40,40); //to give space between buttons

        //to add space around the pane
        fPane.setPadding(new Insets(20));

        Button seat1;
        Button seat2;
        Button seat3;
        Button seat4;
        Button seat5;
        Button seat6;
        Button seat7;
        Button seat8;
        Button seat9;
        Button seat10;
        Button seat11;
        Button seat12;
        Button seat13;
        Button seat14;
        Button seat15;
        Button seat16;
        Button seat17;
        Button seat18;
        Button seat19;
        Button seat20;
        Button seat21;
        Button seat22;
        Button seat23;
        Button seat24;
        Button seat25;
        Button seat26;
        Button seat27;
        Button seat28;
        Button seat29;
        Button seat30;
        Button seat31;
        Button seat32;
        Button seat33;
        Button seat34;
        Button seat35;
        Button seat36;
        Button seat37;
        Button seat38;
        Button seat39;
        Button seat40;
        Button seat41;
        Button seat42;


        seat1=new Button("seat 1");
        seat2=new Button("seat 2");
        seat3=new Button("seat 3");
        seat4=new Button("seat 4");
        seat5=new Button("seat 5");
        seat6=new Button("seat 6");
        seat7=new Button("seat 7");
        seat8=new Button("seat 8");
        seat9=new Button("seat 9");
        seat10=new Button("seat 10");
        seat11=new Button("seat 11");
        seat12=new Button("seat 12");
        seat13=new Button("seat 13");
        seat14=new Button("seat 14");
        seat15=new Button("seat 15");
        seat16=new Button("seat 16");
        seat17=new Button("seat 17");
        seat18=new Button("seat 18");
        seat19=new Button("seat 19");
        seat20=new Button("seat 20");
        seat21=new Button("seat 21");
        seat22=new Button("seat 22");
        seat23=new Button("seat 23");
        seat24=new Button("seat 24");
        seat25=new Button("seat 25");
        seat26=new Button("seat 26");
        seat27=new Button("seat 27");
        seat28=new Button("seat 28");
        seat29=new Button("seat 29");
        seat30=new Button("seat 30");
        seat31=new Button("seat 31");
        seat32=new Button("seat 32");
        seat33=new Button("seat 33");
        seat34=new Button("seat 34");
        seat35=new Button("seat 35");
        seat36=new Button("seat 36");
        seat37=new Button("seat 37");
        seat38=new Button("seat 38");
        seat39=new Button("seat 39");
        seat40=new Button("seat 40");
        seat41=new Button("seat 41");
        seat42=new Button("seat 42");

        Label label1=new Label();
        label1.setText("You can see only the empty seats.");
        fPane.getChildren().add(label1);

        fPane.getChildren().add(seat1);
        fPane.getChildren().add(seat2);
        fPane.getChildren().add(seat3);
        fPane.getChildren().add(seat4);
        fPane.getChildren().add(seat5);
        fPane.getChildren().add(seat6);
        fPane.getChildren().add(seat7);
        fPane.getChildren().add(seat8);
        fPane.getChildren().add(seat9);
        fPane.getChildren().add(seat10);
        fPane.getChildren().add(seat11);
        fPane.getChildren().add(seat12);
        fPane.getChildren().add(seat13);
        fPane.getChildren().add(seat14);
        fPane.getChildren().add(seat15);
        fPane.getChildren().add(seat16);
        fPane.getChildren().add(seat17);
        fPane.getChildren().add(seat18);
        fPane.getChildren().add(seat19);
        fPane.getChildren().add(seat20);
        fPane.getChildren().add(seat21);
        fPane.getChildren().add(seat22);
        fPane.getChildren().add(seat23);
        fPane.getChildren().add(seat24);
        fPane.getChildren().add(seat25);
        fPane.getChildren().add(seat26);
        fPane.getChildren().add(seat27);
        fPane.getChildren().add(seat28);
        fPane.getChildren().add(seat29);
        fPane.getChildren().add(seat30);
        fPane.getChildren().add(seat31);
        fPane.getChildren().add(seat32);
        fPane.getChildren().add(seat33);
        fPane.getChildren().add(seat34);
        fPane.getChildren().add(seat35);
        fPane.getChildren().add(seat36);
        fPane.getChildren().add(seat37);
        fPane.getChildren().add(seat38);
        fPane.getChildren().add(seat39);
        fPane.getChildren().add(seat40);
        fPane.getChildren().add(seat41);
        fPane.getChildren().add(seat42);

        Scene scene=new Scene(fPane,500,900);


        primaryStage.setScene(scene);
        primaryStage.show();


        if (btnList.contains(seat1.getText())){
            seat1.setVisible(false);
        }
        if (btnList.contains(seat2.getText())){
            seat2.setVisible(false);
        }
        if (btnList.contains(seat3.getText())){
            seat3.setVisible(false);
        }
        if (btnList.contains(seat4.getText())){
            seat4.setVisible(false);
        }
        if (btnList.contains(seat5.getText())){
            seat5.setVisible(false);
        }
        if (btnList.contains(seat6.getText())){
            seat6.setVisible(false);
        }
        if (btnList.contains(seat7.getText())){
            seat7.setVisible(false);
        }
        if (btnList.contains(seat8.getText())){
            seat8.setVisible(false);
        }
        if (btnList.contains(seat9.getText())){
            seat9.setVisible(false);
        }

        if (btnList.contains(seat10.getText())){
            seat10.setVisible(false);
        }
        if (btnList.contains(seat11.getText())){
            seat11.setVisible(false);
        }
        if (btnList.contains(seat12.getText())){
            seat12.setVisible(false);
        }
        if (btnList.contains(seat13.getText())){
            seat13.setVisible(false);
        }
        if (btnList.contains(seat14.getText())){
            seat14.setVisible(false);
        }
        if (btnList.contains(seat15.getText())){
            seat15.setVisible(false);
        }
        if (btnList.contains(seat16.getText())){
            seat16.setVisible(false);
        }
        if (btnList.contains(seat17.getText())){
            seat17.setVisible(false);
        }
        if (btnList.contains(seat18.getText())){
            seat18.setVisible(false);
        }
        if (btnList.contains(seat19.getText())){
            seat19.setVisible(false);
        }
        if (btnList.contains(seat20.getText())){
            seat20.setVisible(false);
        }
        if (btnList.contains(seat21.getText())){
            seat21.setVisible(false);
        }
        if (btnList.contains(seat22.getText())){
            seat22.setVisible(false);
        }
        if (btnList.contains(seat23.getText())){
            seat23.setVisible(false);
        }
        if (btnList.contains(seat24.getText())){
            seat24.setVisible(false);
        }
        if (btnList.contains(seat25.getText())){
            seat25.setVisible(false);
        }
        if (btnList.contains(seat26.getText())){
            seat26.setVisible(false);
        }
        if (btnList.contains(seat27.getText())){
            seat27.setVisible(false);
        }
        if (btnList.contains(seat28.getText())){
            seat28.setVisible(false);
        }
        if (btnList.contains(seat29.getText())){
            seat29.setVisible(false);
        }
        if (btnList.contains(seat30.getText())){
            seat30.setVisible(false);
        }
        if (btnList.contains(seat31.getText())){
            seat31.setVisible(false);
        }
        if (btnList.contains(seat32.getText())){
            seat32.setVisible(false);
        }
        if (btnList.contains(seat33.getText())){
            seat33.setVisible(false);
        }
        if (btnList.contains(seat34.getText())){
            seat34.setVisible(false);
        }
        if (btnList.contains(seat35.getText())){
            seat35.setVisible(false);
        }
        if (btnList.contains(seat36.getText())){
            seat36.setVisible(false);
        }
        if (btnList.contains(seat37.getText())){
            seat37.setVisible(false);
        }
        if (btnList.contains(seat38.getText())){
            seat38.setVisible(false);
        }
        if (btnList.contains(seat39.getText())){
            seat39.setVisible(false);
        }
        if (btnList.contains(seat40.getText())){
            seat40.setVisible(false);
        }
        if (btnList.contains(seat41.getText())){
            seat41.setVisible(false);
        }
        if (btnList.contains(seat42.getText())){
            seat42.setVisible(false);
        }

        Button btnMenu;
        btnMenu=new Button();
        btnMenu.setText("Back to options");
        fPane.getChildren().add(btnMenu);

        btnMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    menu(btnList);
                    primaryStage.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private static void delete_seat(ArrayList<String> btnList) {

        //An user can booked their reserved seat by clicking on the relavent seat.
        //after that all the details of the user and that seat will deleted from our arrayLists.
        //after deleting a seat, that seat is available for another user.

        Stage primaryStage = new Stage();
        primaryStage.setTitle("Train Booking System");

        FlowPane fPane=new FlowPane(Orientation.HORIZONTAL,40,40); //to give space between buttons

        //to add space around the pane
        fPane.setPadding(new Insets(20));

        Button seat1;
        Button seat2;
        Button seat3;
        Button seat4;
        Button seat5;
        Button seat6;
        Button seat7;
        Button seat8;
        Button seat9;
        Button seat10;
        Button seat11;
        Button seat12;
        Button seat13;
        Button seat14;
        Button seat15;
        Button seat16;
        Button seat17;
        Button seat18;
        Button seat19;
        Button seat20;
        Button seat21;
        Button seat22;
        Button seat23;
        Button seat24;
        Button seat25;
        Button seat26;
        Button seat27;
        Button seat28;
        Button seat29;
        Button seat30;
        Button seat31;
        Button seat32;
        Button seat33;
        Button seat34;
        Button seat35;
        Button seat36;
        Button seat37;
        Button seat38;
        Button seat39;
        Button seat40;
        Button seat41;
        Button seat42;


        seat1=new Button("seat 1");
        seat2=new Button("seat 2");
        seat3=new Button("seat 3");
        seat4=new Button("seat 4");
        seat5=new Button("seat 5");
        seat6=new Button("seat 6");
        seat7=new Button("seat 7");
        seat8=new Button("seat 8");
        seat9=new Button("seat 9");
        seat10=new Button("seat 10");
        seat11=new Button("seat 11");
        seat12=new Button("seat 12");
        seat13=new Button("seat 13");
        seat14=new Button("seat 14");
        seat15=new Button("seat 15");
        seat16=new Button("seat 16");
        seat17=new Button("seat 17");
        seat18=new Button("seat 18");
        seat19=new Button("seat 19");
        seat20=new Button("seat 20");
        seat21=new Button("seat 21");
        seat22=new Button("seat 22");
        seat23=new Button("seat 23");
        seat24=new Button("seat 24");
        seat25=new Button("seat 25");
        seat26=new Button("seat 26");
        seat27=new Button("seat 27");
        seat28=new Button("seat 28");
        seat29=new Button("seat 29");
        seat30=new Button("seat 30");
        seat31=new Button("seat 31");
        seat32=new Button("seat 32");
        seat33=new Button("seat 33");
        seat34=new Button("seat 34");
        seat35=new Button("seat 35");
        seat36=new Button("seat 36");
        seat37=new Button("seat 37");
        seat38=new Button("seat 38");
        seat39=new Button("seat 39");
        seat40=new Button("seat 40");
        seat41=new Button("seat 41");
        seat42=new Button("seat 42");

        Label label1=new Label();
        label1.setText("Green colour seats are your reserved seats.  Click on your relevant reserved seat to cancel the reservation");
        fPane.getChildren().add(label1);

        fPane.getChildren().add(seat1);
        fPane.getChildren().add(seat2);
        fPane.getChildren().add(seat3);
        fPane.getChildren().add(seat4);
        fPane.getChildren().add(seat5);
        fPane.getChildren().add(seat6);
        fPane.getChildren().add(seat7);
        fPane.getChildren().add(seat8);
        fPane.getChildren().add(seat9);
        fPane.getChildren().add(seat10);
        fPane.getChildren().add(seat11);
        fPane.getChildren().add(seat12);
        fPane.getChildren().add(seat13);
        fPane.getChildren().add(seat14);
        fPane.getChildren().add(seat15);
        fPane.getChildren().add(seat16);
        fPane.getChildren().add(seat17);
        fPane.getChildren().add(seat18);
        fPane.getChildren().add(seat19);
        fPane.getChildren().add(seat20);
        fPane.getChildren().add(seat21);
        fPane.getChildren().add(seat22);
        fPane.getChildren().add(seat23);
        fPane.getChildren().add(seat24);
        fPane.getChildren().add(seat25);
        fPane.getChildren().add(seat26);
        fPane.getChildren().add(seat27);
        fPane.getChildren().add(seat28);
        fPane.getChildren().add(seat29);
        fPane.getChildren().add(seat30);
        fPane.getChildren().add(seat31);
        fPane.getChildren().add(seat32);
        fPane.getChildren().add(seat33);
        fPane.getChildren().add(seat34);
        fPane.getChildren().add(seat35);
        fPane.getChildren().add(seat36);
        fPane.getChildren().add(seat37);
        fPane.getChildren().add(seat38);
        fPane.getChildren().add(seat39);
        fPane.getChildren().add(seat40);
        fPane.getChildren().add(seat41);
        fPane.getChildren().add(seat42);

        Scene scene=new Scene(fPane,500,900);

        primaryStage.setScene(scene);
        primaryStage.show();

        //I am checking the seat for that relevent customer using his/her NIC number. Because NIC number is unique.
        //after that he/she can see his/her booked seats in green colour.

        if (userDetails1.contains(userNIC)){
            seat1.setStyle("-fx-background-color: Green");

            seat1.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat1.setStyle("-fx-background-color: Red");
                    btnList.remove(seat1.getText());
                    userDetails1.clear();

                }
            });

        }
        if (userDetails2.contains(userNIC) ){
            seat2.setStyle("-fx-background-color: Green");

            seat2.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat2.setStyle("-fx-background-color: Red");
                    btnList.remove(seat2.getText());
                    userDetails2.clear();
                }
            });

        }
        if (userDetails3.contains(userNIC)){
            seat3.setStyle("-fx-background-color: Green");

            seat3.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat3.setStyle("-fx-background-color: Red");
                    btnList.remove(seat3.getText());
                    userDetails3.clear();
                }
            });

        }
        if (userDetails4.contains(userNIC)){
            seat4.setStyle("-fx-background-color: Green");

            seat4.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat4.setStyle("-fx-background-color: Red");
                    btnList.remove(seat4.getText());
                    userDetails4.clear();
                }
            });

        }
        if (userDetails5.contains(userNIC)){
            seat5.setStyle("-fx-background-color: Green");

            seat5.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat5.setStyle("-fx-background-color: Red");
                    btnList.remove(seat5.getText());
                    userDetails5.clear();
                }
            });


        }
        if (userDetails6.contains(userNIC)){
            seat6.setStyle("-fx-background-color: Green");

            seat6.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat6.setStyle("-fx-background-color: Red");
                    btnList.remove(seat6.getText());
                    userDetails6.clear();
                }
            });


        }
        if (userDetails7.contains(userNIC)){
            seat7.setStyle("-fx-background-color: Green");

            seat7.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat7.setStyle("-fx-background-color: Red");
                    btnList.remove(seat7.getText());
                    userDetails7.clear();
                }
            });


        }
        if (userDetails8.contains(userNIC)){
            seat8.setStyle("-fx-background-color: Green");

            seat8.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat8.setStyle("-fx-background-color: Red");
                    btnList.remove(seat8.getText());
                    userDetails8.clear();
                }
            });


        }
        if (userDetails9.contains(userNIC)){
            seat9.setStyle("-fx-background-color: Green");

            seat9.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat9.setStyle("-fx-background-color: Red");
                    btnList.remove(seat9.getText());
                    userDetails9.clear();
                }
            });


        }

        if (userDetails10.contains(userNIC)){
            seat10.setStyle("-fx-background-color: Green");

            seat10.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat10.setStyle("-fx-background-color: Red");
                    btnList.remove(seat10.getText());
                    userDetails10.clear();
                }
            });


        }
        if (userDetails11.contains(userNIC)){
            seat11.setStyle("-fx-background-color: Green");

            seat11.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat11.setStyle("-fx-background-color: Red");
                    btnList.remove(seat11.getText());
                    userDetails11.clear();
                }
            });


        }
        if (userDetails12.contains(userNIC)){
            seat12.setStyle("-fx-background-color: Green");

            seat12.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat12.setStyle("-fx-background-color: Red");
                    btnList.remove(seat12.getText());
                    userDetails12.clear();
                }
            });


        }
        if (userDetails13.contains(userNIC)){
            seat13.setStyle("-fx-background-color: Green");

            seat13.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat13.setStyle("-fx-background-color: Red");
                    btnList.remove(seat13.getText());
                    userDetails13.clear();
                }
            });


        }
        if (userDetails14.contains(userNIC)){
            seat14.setStyle("-fx-background-color: Green");

            seat14.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat14.setStyle("-fx-background-color: Red");
                    btnList.remove(seat14.getText());
                    userDetails14.clear();
                }
            });


        }
        if (userDetails15.contains(userNIC)){
            seat15.setStyle("-fx-background-color: Green");

            seat15.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat15.setStyle("-fx-background-color: Red");
                    btnList.remove(seat15.getText());
                    userDetails15.clear();
                }
            });


        }
        if (userDetails16.contains(userNIC)){
            seat16.setStyle("-fx-background-color: Green");

            seat16.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat16.setStyle("-fx-background-color: Red");
                    btnList.remove(seat16.getText());
                    userDetails16.clear();
                }
            });


        }
        if (userDetails17.contains(userNIC)){
            seat17.setStyle("-fx-background-color: Green");

            seat17.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat17.setStyle("-fx-background-color: Red");
                    btnList.remove(seat17.getText());
                    userDetails17.clear();
                }
            });


        }
        if (userDetails18.contains(userNIC)){
            seat18.setStyle("-fx-background-color: Green");

            seat18.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat18.setStyle("-fx-background-color: Red");
                    btnList.remove(seat18.getText());
                    userDetails18.clear();
                }
            });


        }
        if (userDetails19.contains(userNIC)){
            seat19.setStyle("-fx-background-color: Green");

            seat19.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat19.setStyle("-fx-background-color: Red");
                    btnList.remove(seat19.getText());
                    userDetails19.clear();
                }
            });


        }
        if (userDetails20.contains(userNIC)){
            seat20.setStyle("-fx-background-color: Green");

            seat20.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat20.setStyle("-fx-background-color: Red");
                    btnList.remove(seat20.getText());
                    userDetails20.clear();
                }
            });


        }
        if (userDetails21.contains(userNIC)){
            seat21.setStyle("-fx-background-color: Green");

            seat21.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat21.setStyle("-fx-background-color: Red");
                    btnList.remove(seat21.getText());
                    userDetails21.clear();
                }
            });


        }
        if (userDetails22.contains(userNIC)){
            seat22.setStyle("-fx-background-color: Green");

            seat22.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat22.setStyle("-fx-background-color: Red");
                    btnList.remove(seat22.getText());
                    userDetails22.clear();
                }
            });


        }
        if (userDetails23.contains(userNIC)){
            seat23.setStyle("-fx-background-color: Green");

            seat23.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat23.setStyle("-fx-background-color: Red");
                    btnList.remove(seat23.getText());
                    userDetails23.clear();
                }
            });


        }
        if (userDetails24.contains(userNIC)){
            seat24.setStyle("-fx-background-color: Green");

            seat24.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat24.setStyle("-fx-background-color: Red");
                    btnList.remove(seat24.getText());
                    userDetails24.clear();
                }
            });


        }
        if (userDetails25.contains(userNIC)){
            seat25.setStyle("-fx-background-color: Green");

            seat25.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat25.setStyle("-fx-background-color: Red");
                    btnList.remove(seat25.getText());
                    userDetails25.clear();
                }
            });


        }
        if (userDetails26.contains(userNIC)){
            seat26.setStyle("-fx-background-color: Green");

            seat26.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat26.setStyle("-fx-background-color: Red");
                    btnList.remove(seat26.getText());
                    userDetails26.clear();
                }
            });


        }
        if (userDetails27.contains(userNIC)){
            seat27.setStyle("-fx-background-color: Green");

            seat27.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat27.setStyle("-fx-background-color: Red");
                    btnList.remove(seat27.getText());
                    userDetails27.clear();
                }
            });


        }
        if (userDetails28.contains(userNIC)){
            seat28.setStyle("-fx-background-color: Green");

            seat28.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat28.setStyle("-fx-background-color: Red");
                    btnList.remove(seat28.getText());
                    userDetails28.clear();
                }
            });


        }
        if (userDetails29.contains(userNIC)){
            seat29.setStyle("-fx-background-color: Green");

            seat29.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat29.setStyle("-fx-background-color: Red");
                    btnList.remove(seat29.getText());
                    userDetails29.clear();
                }
            });


        }
        if (userDetails30.contains(userNIC)){
            seat30.setStyle("-fx-background-color: Green");

            seat30.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat30.setStyle("-fx-background-color: Red");
                    btnList.remove(seat30.getText());
                    userDetails30.clear();
                }
            });


        }
        if (userDetails31.contains(userNIC)){
            seat31.setStyle("-fx-background-color: Green");

            seat31.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat31.setStyle("-fx-background-color: Red");
                    btnList.remove(seat31.getText());
                    userDetails31.clear();
                }
            });


        }
        if (userDetails32.contains(userNIC)){
            seat32.setStyle("-fx-background-color: Green");

            seat32.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat32.setStyle("-fx-background-color: Red");
                    btnList.remove(seat32.getText());
                    userDetails32.clear();
                }
            });


        }
        if (userDetails33.contains(userNIC)){
            seat33.setStyle("-fx-background-color: Green");

            seat33.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat33.setStyle("-fx-background-color: Red");
                    btnList.remove(seat33.getText());
                    userDetails33.clear();
                }
            });


        }
        if (userDetails34.contains(userNIC)){
            seat34.setStyle("-fx-background-color: Green");

            seat34.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat34.setStyle("-fx-background-color: Red");
                    btnList.remove(seat34.getText());
                    userDetails34.clear();
                }
            });


        }
        if (userDetails35.contains(userNIC)){
            seat35.setStyle("-fx-background-color: Green");

            seat35.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat35.setStyle("-fx-background-color: Red");
                    btnList.remove(seat35.getText());
                    userDetails35.clear();
                }
            });


        }
        if (userDetails36.contains(userNIC)){
            seat36.setStyle("-fx-background-color: Green");

            seat36.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat36.setStyle("-fx-background-color: Red");
                    btnList.remove(seat36.getText());
                    userDetails36.clear();
                }
            });


        }
        if (userDetails37.contains(userNIC)){
            seat37.setStyle("-fx-background-color: Green");

            seat37.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat37.setStyle("-fx-background-color: Red");
                    btnList.remove(seat37.getText());
                    userDetails37.clear();
                }
            });


        }
        if (userDetails38.contains(userNIC)){
            seat38.setStyle("-fx-background-color: Green");

            seat38.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat38.setStyle("-fx-background-color: Red");
                    btnList.remove(seat38.getText());
                    userDetails38.clear();
                }
            });


        }
        if (userDetails39.contains(userNIC)){
            seat39.setStyle("-fx-background-color: Green");

            seat39.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat39.setStyle("-fx-background-color: Red");
                    btnList.remove(seat39.getText());
                    userDetails39.clear();
                }
            });


        }
        if (userDetails40.contains(userNIC)){
            seat40.setStyle("-fx-background-color: Green");

            seat40.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat40.setStyle("-fx-background-color: Red");
                    btnList.remove(seat40.getText());
                    userDetails40.clear();
                }
            });


        }
        if (userDetails41.contains(userNIC)){
            seat41.setStyle("-fx-background-color: Green");

            seat41.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat41.setStyle("-fx-background-color: Red");
                    btnList.remove(seat41.getText());
                    userDetails41.clear();
                }
            });


        }
        if (userDetails42.contains(userNIC)){
            seat42.setStyle("-fx-background-color: Green");

            seat42.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    seat42.setStyle("-fx-background-color: Red");
                    btnList.remove(seat42.getText());
                    userDetails42.clear();
                }
            });


        }

        Button btnMenu;
        btnMenu=new Button();
        btnMenu.setText("Back to options");
        fPane.getChildren().add(btnMenu);

        btnMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    menu(btnList);
                    primaryStage.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private static void find_seats(ArrayList<String> btnList) {

        //if a user choose F option, it will call this method.

        Stage primaryStage = new Stage();
        primaryStage.setTitle("Train Booking System");

        FlowPane fPane=new FlowPane(Orientation.HORIZONTAL,40,40); //to give space between buttons

        //to add space around the pane
        fPane.setPadding(new Insets(20));

        Button seat1;
        Button seat2;
        Button seat3;
        Button seat4;
        Button seat5;
        Button seat6;
        Button seat7;
        Button seat8;
        Button seat9;
        Button seat10;
        Button seat11;
        Button seat12;
        Button seat13;
        Button seat14;
        Button seat15;
        Button seat16;
        Button seat17;
        Button seat18;
        Button seat19;
        Button seat20;
        Button seat21;
        Button seat22;
        Button seat23;
        Button seat24;
        Button seat25;
        Button seat26;
        Button seat27;
        Button seat28;
        Button seat29;
        Button seat30;
        Button seat31;
        Button seat32;
        Button seat33;
        Button seat34;
        Button seat35;
        Button seat36;
        Button seat37;
        Button seat38;
        Button seat39;
        Button seat40;
        Button seat41;
        Button seat42;


        seat1=new Button("seat 1");
        seat2=new Button("seat 2");
        seat3=new Button("seat 3");
        seat4=new Button("seat 4");
        seat5=new Button("seat 5");
        seat6=new Button("seat 6");
        seat7=new Button("seat 7");
        seat8=new Button("seat 8");
        seat9=new Button("seat 9");
        seat10=new Button("seat 10");
        seat11=new Button("seat 11");
        seat12=new Button("seat 12");
        seat13=new Button("seat 13");
        seat14=new Button("seat 14");
        seat15=new Button("seat 15");
        seat16=new Button("seat 16");
        seat17=new Button("seat 17");
        seat18=new Button("seat 18");
        seat19=new Button("seat 19");
        seat20=new Button("seat 20");
        seat21=new Button("seat 21");
        seat22=new Button("seat 22");
        seat23=new Button("seat 23");
        seat24=new Button("seat 24");
        seat25=new Button("seat 25");
        seat26=new Button("seat 26");
        seat27=new Button("seat 27");
        seat28=new Button("seat 28");
        seat29=new Button("seat 29");
        seat30=new Button("seat 30");
        seat31=new Button("seat 31");
        seat32=new Button("seat 32");
        seat33=new Button("seat 33");
        seat34=new Button("seat 34");
        seat35=new Button("seat 35");
        seat36=new Button("seat 36");
        seat37=new Button("seat 37");
        seat38=new Button("seat 38");
        seat39=new Button("seat 39");
        seat40=new Button("seat 40");
        seat41=new Button("seat 41");
        seat42=new Button("seat 42");

        Label label1=new Label();
        label1.setText("These are your reserved seats.");
        fPane.getChildren().add(label1);

        fPane.getChildren().add(seat1);
        fPane.getChildren().add(seat2);
        fPane.getChildren().add(seat3);
        fPane.getChildren().add(seat4);
        fPane.getChildren().add(seat5);
        fPane.getChildren().add(seat6);
        fPane.getChildren().add(seat7);
        fPane.getChildren().add(seat8);
        fPane.getChildren().add(seat9);
        fPane.getChildren().add(seat10);
        fPane.getChildren().add(seat11);
        fPane.getChildren().add(seat12);
        fPane.getChildren().add(seat13);
        fPane.getChildren().add(seat14);
        fPane.getChildren().add(seat15);
        fPane.getChildren().add(seat16);
        fPane.getChildren().add(seat17);
        fPane.getChildren().add(seat18);
        fPane.getChildren().add(seat19);
        fPane.getChildren().add(seat20);
        fPane.getChildren().add(seat21);
        fPane.getChildren().add(seat22);
        fPane.getChildren().add(seat23);
        fPane.getChildren().add(seat24);
        fPane.getChildren().add(seat25);
        fPane.getChildren().add(seat26);
        fPane.getChildren().add(seat27);
        fPane.getChildren().add(seat28);
        fPane.getChildren().add(seat29);
        fPane.getChildren().add(seat30);
        fPane.getChildren().add(seat31);
        fPane.getChildren().add(seat32);
        fPane.getChildren().add(seat33);
        fPane.getChildren().add(seat34);
        fPane.getChildren().add(seat35);
        fPane.getChildren().add(seat36);
        fPane.getChildren().add(seat37);
        fPane.getChildren().add(seat38);
        fPane.getChildren().add(seat39);
        fPane.getChildren().add(seat40);
        fPane.getChildren().add(seat41);
        fPane.getChildren().add(seat42);

        Scene scene=new Scene(fPane,500,900);

        primaryStage.setScene(scene);
        primaryStage.show();

        //if user entered name is in the userDetails1 arrayList, that means that user booked seat1.
        //The relevent user can see his/her reserved seats only. Other seats are not visible.


        if (userDetails1.contains(userName)) {
            seat1.setVisible(true);
        }else {
            seat1.setVisible(false);
        }

        if (userDetails2.contains(userName)) {
            seat2.setVisible(true);
        }else {
            seat2.setVisible(false);
        }

        if (userDetails3.contains(userName)) {
            seat3.setVisible(true);
        }else {
            seat3.setVisible(false);
        }

        if (userDetails4.contains(userName)) {
            seat4.setVisible(true);
        }else {
            seat4.setVisible(false);
        }

        if (userDetails5.contains(userName)) {
            seat5.setVisible(true);
        }else {
            seat5.setVisible(false);
        }

        if (userDetails6.contains(userName)) {
            seat6.setVisible(true);
        }else {
            seat6.setVisible(false);
        }

        if (userDetails7.contains(userName)) {
            seat7.setVisible(true);
        }else {
            seat7.setVisible(false);
        }

        if (userDetails8.contains(userName)) {
            seat8.setVisible(true);
        }else {
            seat8.setVisible(false);
        }

        if (userDetails9.contains(userName)) {
            seat9.setVisible(true);
        }else {
            seat9.setVisible(false);
        }

        if (userDetails10.contains(userName)) {
            seat10.setVisible(true);
        }else {
            seat10.setVisible(false);
        }

        if (userDetails11.contains(userName)) {
            seat11.setVisible(true);
        }else {
            seat11.setVisible(false);
        }

        if (userDetails12.contains(userName)) {
            seat12.setVisible(true);
        }else {
            seat12.setVisible(false);
        }

        if (userDetails13.contains(userName)) {
            seat13.setVisible(true);
        }else {
            seat13.setVisible(false);
        }

        if (userDetails14.contains(userName)) {
            seat14.setVisible(true);
        }else {
            seat14.setVisible(false);
        }

        if (userDetails15.contains(userName)) {
            seat15.setVisible(true);
        }else {
            seat15.setVisible(false);
        }

        if (userDetails16.contains(userName)) {
            seat16.setVisible(true);
        }else {
            seat16.setVisible(false);
        }

        if (userDetails17.contains(userName)) {
            seat17.setVisible(true);
        }else {
            seat17.setVisible(false);
        }

        if (userDetails18.contains(userName)) {
            seat18.setVisible(true);
        }else {
            seat18.setVisible(false);
        }

        if (userDetails19.contains(userName)) {
            seat19.setVisible(true);
        }else {
            seat19.setVisible(false);
        }

        if (userDetails20.contains(userName)) {
            seat20.setVisible(true);
        }else {
            seat20.setVisible(false);
        }

        if (userDetails21.contains(userName)) {
            seat21.setVisible(true);
        }else {
            seat21.setVisible(false);
        }

        if (userDetails22.contains(userName)) {
            seat22.setVisible(true);
        }else {
            seat22.setVisible(false);
        }

        if (userDetails23.contains(userName)) {
            seat23.setVisible(true);
        }else {
            seat23.setVisible(false);
        }

        if (userDetails24.contains(userName)) {
            seat24.setVisible(true);
        }else {
            seat24.setVisible(false);
        }

        if (userDetails25.contains(userName)) {
            seat25.setVisible(true);
        }else {
            seat25.setVisible(false);
        }

        if (userDetails26.contains(userName)) {
            seat26.setVisible(true);
        }else {
            seat26.setVisible(false);
        }

        if (userDetails27.contains(userName)) {
            seat27.setVisible(true);
        }else {
            seat27.setVisible(false);
        }

        if (userDetails28.contains(userName)) {
            seat28.setVisible(true);
        }else {
            seat28.setVisible(false);
        }

        if (userDetails29.contains(userName)) {
            seat29.setVisible(true);
        }else {
            seat29.setVisible(false);
        }

        if (userDetails30.contains(userName)) {
            seat30.setVisible(true);
        }else {
            seat30.setVisible(false);
        }

        if (userDetails31.contains(userName)) {
            seat31.setVisible(true);
        }else {
            seat31.setVisible(false);
        }

        if (userDetails32.contains(userName)) {
            seat32.setVisible(true);
        }else {
            seat32.setVisible(false);
        }

        if (userDetails33.contains(userName)) {
            seat33.setVisible(true);
        }else {
            seat33.setVisible(false);
        }

        if (userDetails34.contains(userName)) {
            seat34.setVisible(true);
        }else {
            seat34.setVisible(false);
        }

        if (userDetails35.contains(userName)) {
            seat35.setVisible(true);
        }else {
            seat35.setVisible(false);
        }

        if (userDetails36.contains(userName)) {
            seat36.setVisible(true);
        }else {
            seat36.setVisible(false);
        }

        if (userDetails37.contains(userName)) {
            seat37.setVisible(true);
        }else {
            seat37.setVisible(false);
        }

        if (userDetails38.contains(userName)) {
            seat38.setVisible(true);
        }else {
            seat38.setVisible(false);
        }

        if (userDetails39.contains(userName)) {
            seat39.setVisible(true);
        }else {
            seat39.setVisible(false);
        }

        if (userDetails40.contains(userName)) {
            seat40.setVisible(true);
        }else {
            seat40.setVisible(false);
        }

        if (userDetails41.contains(userName)) {
            seat41.setVisible(true);
        }else {
            seat41.setVisible(false);
        }

        if (userDetails42.contains(userName)) {
            seat42.setVisible(true);
        }else {
            seat42.setVisible(false);
        }

        Button btnMenu;
        btnMenu=new Button();
        btnMenu.setText("Back to options");
        fPane.getChildren().add(btnMenu);

        btnMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    menu(btnList);
                    primaryStage.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
    private static void quit() {

        //user can exit from the program by choosing Q option. because after choosing Q system will this method.

        System.out.println("Thank you!");
        System.exit(1);
    }

    private static void order(ArrayList<String> btnList) {

        //here you can see all the booked seats into an order.(not seat1 to seat42)
        //Ordered alphabetically by name of all the users.

        Stage primaryStage = new Stage();
        primaryStage.setTitle("Train Booking System");

        FlowPane fPane=new FlowPane(Orientation.HORIZONTAL,40,40); //to give space between buttons

        //to add space around the pane
        fPane.setPadding(new Insets(20));

        Button seat1;
        Button seat2;
        Button seat3;
        Button seat4;
        Button seat5;
        Button seat6;
        Button seat7;
        Button seat8;
        Button seat9;
        Button seat10;
        Button seat11;
        Button seat12;
        Button seat13;
        Button seat14;
        Button seat15;
        Button seat16;
        Button seat17;
        Button seat18;
        Button seat19;
        Button seat20;
        Button seat21;
        Button seat22;
        Button seat23;
        Button seat24;
        Button seat25;
        Button seat26;
        Button seat27;
        Button seat28;
        Button seat29;
        Button seat30;
        Button seat31;
        Button seat32;
        Button seat33;
        Button seat34;
        Button seat35;
        Button seat36;
        Button seat37;
        Button seat38;
        Button seat39;
        Button seat40;
        Button seat41;
        Button seat42;

        Button btnMenu;
        btnMenu=new Button();
        btnMenu.setText("Back to options");
        fPane.getChildren().add(btnMenu);

        btnMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    menu(btnList);
                    primaryStage.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });


        seat1=new Button("seat 1");
        seat2=new Button("seat 2");
        seat3=new Button("seat 3");
        seat4=new Button("seat 4");
        seat5=new Button("seat 5");
        seat6=new Button("seat 6");
        seat7=new Button("seat 7");
        seat8=new Button("seat 8");
        seat9=new Button("seat 9");
        seat10=new Button("seat 10");
        seat11=new Button("seat 11");
        seat12=new Button("seat 12");
        seat13=new Button("seat 13");
        seat14=new Button("seat 14");
        seat15=new Button("seat 15");
        seat16=new Button("seat 16");
        seat17=new Button("seat 17");
        seat18=new Button("seat 18");
        seat19=new Button("seat 19");
        seat20=new Button("seat 20");
        seat21=new Button("seat 21");
        seat22=new Button("seat 22");
        seat23=new Button("seat 23");
        seat24=new Button("seat 24");
        seat25=new Button("seat 25");
        seat26=new Button("seat 26");
        seat27=new Button("seat 27");
        seat28=new Button("seat 28");
        seat29=new Button("seat 29");
        seat30=new Button("seat 30");
        seat31=new Button("seat 31");
        seat32=new Button("seat 32");
        seat33=new Button("seat 33");
        seat34=new Button("seat 34");
        seat35=new Button("seat 35");
        seat36=new Button("seat 36");
        seat37=new Button("seat 37");
        seat38=new Button("seat 38");
        seat39=new Button("seat 39");
        seat40=new Button("seat 40");
        seat41=new Button("seat 41");
        seat42=new Button("seat 42");


        Scene scene=new Scene(fPane,500,900);

        primaryStage.setScene(scene);
        primaryStage.show();

        //first lets sort the allNames list into alphabetical order.
        String temp;
        for (int i = 0; i < allNames.size(); i++) {
            for (int j = i + 1; j < allNames.size(); j++) {
                if (allNames.get(i).compareTo(allNames.get(j)) > 0) {
                    temp = allNames.get(i);
                    allNames.set(i, allNames.get(j));
                    allNames.set(j, temp);
                }
            }
        }

        //after that i have used a hashset to store names after sorting because it doesnt contain any duplicate elements.

        HashSet<String>set = new HashSet<String>(allNames);
        List<String>allNames2 = new ArrayList<String>(set);

        // i means each element in the hashset. it loops 1st element to last element of the hashset.
        // if 1st element is in the userDetails1 arraList, that person has booked seat1. so gui shows that seat.
        // if that 1st element person booked several seats, gui shows all of them at the first.

        for (Object i:allNames2){

            if (userDetails1.contains(i)) {
                fPane.getChildren().add(seat1);
            }
            if (userDetails2.contains(i)) {
                fPane.getChildren().add(seat2);
            }
            if (userDetails3.contains(i)) {
                fPane.getChildren().add(seat3);
            }
            if (userDetails4.contains(i)) {
                fPane.getChildren().add(seat4);
            }
            if (userDetails5.contains(i)) {
                fPane.getChildren().add(seat5);
            }
            if (userDetails6.contains(i)) {
                fPane.getChildren().add(seat6);
            }
            if (userDetails7.contains(i)) {
                fPane.getChildren().add(seat7);
            }
            if (userDetails8.contains(i)) {
                fPane.getChildren().add(seat8);
            }
            if (userDetails9.contains(i)) {
                fPane.getChildren().add(seat9);
            }
            if (userDetails10.contains(i)) {
                fPane.getChildren().add(seat10);
            }
            if (userDetails11.contains(i)) {
                fPane.getChildren().add(seat11);
            }
            if (userDetails12.contains(i)) {
                fPane.getChildren().add(seat12);
            }
            if (userDetails13.contains(i)) {
                fPane.getChildren().add(seat13);
            }
            if (userDetails14.contains(i)) {
                fPane.getChildren().add(seat14);
            }
            if (userDetails15.contains(i)) {
                fPane.getChildren().add(seat15);
            }
            if (userDetails16.contains(i)) {
                fPane.getChildren().add(seat16);
            }
            if (userDetails17.contains(i)) {
                fPane.getChildren().add(seat17);
            }
            if (userDetails18.contains(i)) {
                fPane.getChildren().add(seat18);
            }
            if (userDetails19.contains(i)) {
                fPane.getChildren().add(seat19);
            }
            if (userDetails20.contains(i)) {
                fPane.getChildren().add(seat20);
            }
            if (userDetails21.contains(i)) {
                fPane.getChildren().add(seat21);
            }
            if (userDetails22.contains(i)) {
                fPane.getChildren().add(seat22);
            }
            if (userDetails23.contains(i)) {
                fPane.getChildren().add(seat23);
            }
            if (userDetails24.contains(i)) {
                fPane.getChildren().add(seat24);
            }
            if (userDetails25.contains(i)) {
                fPane.getChildren().add(seat25);
            }
            if (userDetails26.contains(i)) {
                fPane.getChildren().add(seat26);
            }
            if (userDetails27.contains(i)) {
                fPane.getChildren().add(seat27);
            }
            if (userDetails28.contains(i)) {
                fPane.getChildren().add(seat28);
            }
            if (userDetails29.contains(i)) {
                fPane.getChildren().add(seat29);
            }
            if (userDetails30.contains(i)) {
                fPane.getChildren().add(seat30);
            }
            if (userDetails31.contains(i)) {
                fPane.getChildren().add(seat31);
            }
            if (userDetails32.contains(i)) {
                fPane.getChildren().add(seat32);
            }
            if (userDetails33.contains(i)) {
                fPane.getChildren().add(seat33);
            }
            if (userDetails34.contains(i)) {
                fPane.getChildren().add(seat34);
            }
            if (userDetails35.contains(i)) {
                fPane.getChildren().add(seat35);
            }
            if (userDetails36.contains(i)) {
                fPane.getChildren().add(seat36);
            }
            if (userDetails37.contains(i)) {
                fPane.getChildren().add(seat37);
            }
            if (userDetails38.contains(i)) {
                fPane.getChildren().add(seat38);
            }
            if (userDetails39.contains(i)) {
                fPane.getChildren().add(seat39);
            }
            if (userDetails40.contains(i)) {
                fPane.getChildren().add(seat40);
            }
            if (userDetails41.contains(i)) {
                fPane.getChildren().add(seat41);
            }
            if (userDetails42.contains(i)) {
                fPane.getChildren().add(seat42);
            }

        }

    }

    private static void store(ArrayList<String> btnList) throws IOException {

        //In here, i am storing all the user seats details in a file for that specific seat.
        try {
            File fileName1 = new File("User1");
            FileWriter fw1 = new FileWriter(fileName1);
            Writer output1 = new BufferedWriter(fw1);
            int sz1 = userDetails1.size();
            for (int i = 0; i < sz1; i++) {
                output1.write(userDetails1.get(i).toString() + "\n");
            }
            output1.close();
        }catch (Exception e){
            System.out.println("1st seat is empty");
        }
try{
        File fileName2=new File("User2");
        FileWriter fw2=new FileWriter(fileName2);
        Writer output2= new BufferedWriter(fw2);
        int sz2=userDetails2.size();
        for(int i=0;i<sz2;i++){
            output2.write(userDetails2.get(i).toString()+"\n");
        }
        output2.close();
    }catch (Exception e){
        System.out.println("2st seat is empty");
    }
try{
        File fileName3=new File("User3");
        FileWriter fw3=new FileWriter(fileName3);
        Writer output3= new BufferedWriter(fw3);
        int sz3=userDetails3.size();
        for(int i=0;i<sz3;i++){
            output3.write(userDetails3.get(i).toString()+"\n");
        }
        output3.close();
    }catch (Exception e){
        System.out.println("3rd seat is empty");
    }
try{
        File fileName4=new File("User4");
        FileWriter fw4=new FileWriter(fileName4);
        Writer output4= new BufferedWriter(fw4);
        int sz4 =userDetails4.size();
        for(int i=0;i<sz4;i++){
            output4.write(userDetails4.get(i).toString()+"\n");
        }
        output4.close();
    }catch (Exception e){
        System.out.println("4th seat is empty");
    }
try{
        File fileName5=new File("User5");
        FileWriter fw5=new FileWriter(fileName5);
        Writer output5= new BufferedWriter(fw5);
        int sz5=userDetails5.size();
        for(int i=0;i<sz5;i++){
            output5.write(userDetails5.get(i).toString()+"\n");
        }
        output5.close();
    }catch (Exception e){
        System.out.println("5th seat is empty");
    }
try{
        File fileName6=new File("User6");
        FileWriter fw6=new FileWriter(fileName6);
        Writer output6= new BufferedWriter(fw6);
        int sz6=userDetails6.size();
        for(int i=0;i<sz6;i++){
            output6.write(userDetails6.get(i).toString()+"\n");
        }
        output6.close();
    }catch (Exception e){
        System.out.println("6th seat is empty");
    }
try{
        File fileName7=new File("User7");
        FileWriter fw7=new FileWriter(fileName7);
        Writer output7= new BufferedWriter(fw7);
        int sz7=userDetails7.size();
        for(int i=0;i<sz7;i++){
            output7.write(userDetails7.get(i).toString()+"\n");
        }
        output7.close();
    }catch (Exception e){
        System.out.println("7th seat is empty");
    }
try{
        File fileName8=new File("User8");
        FileWriter fw8=new FileWriter(fileName8);
        Writer output8= new BufferedWriter(fw8);
        int sz8=userDetails8.size();
        for(int i=0;i<sz8;i++){
            output8.write(userDetails8.get(i).toString()+"\n");
        }
        output8.close();
    }catch (Exception e){
        System.out.println("8th seat is empty");
    }
try{
        File fileName9=new File("User9");
        FileWriter fw9=new FileWriter(fileName9);
        Writer output9= new BufferedWriter(fw9);
        int sz9=userDetails9.size();
        for(int i=0;i<sz9;i++){
            output9.write(userDetails9.get(i).toString()+"\n");
        }
        output9.close();
    }catch (Exception e){
        System.out.println("9th seat is empty");
    }
try{
        File fileName10=new File("User10");
        FileWriter fw10=new FileWriter(fileName10);
        Writer output10= new BufferedWriter(fw10);
        int sz10=userDetails10.size();
        for(int i=0;i<sz10;i++){
            output10.write(userDetails10.get(i).toString()+"\n");
        }
        output10.close();
    }catch (Exception e){
        System.out.println("10th seat is empty");
    }
try{
        File fileName11=new File("User11");
        FileWriter fw11=new FileWriter(fileName11);
        Writer output11= new BufferedWriter(fw11);
        int sz11=userDetails11.size();
        for(int i=0;i<sz11;i++){
            output11.write(userDetails11.get(i).toString()+"\n");
        }
        output11.close();
    }catch (Exception e){
        System.out.println("11th seat is empty");
    }
try{
        File fileName12=new File("User12");
        FileWriter fw12=new FileWriter(fileName12);
        Writer output12= new BufferedWriter(fw12);
        int sz12=userDetails12.size();
        for(int i=0;i<sz12;i++){
            output12.write(userDetails12.get(i).toString()+"\n");
        }
        output12.close();
    }catch (Exception e){
        System.out.println("12th seat is empty");
    }
try{
        File fileName13=new File("User13");
        FileWriter fw13=new FileWriter(fileName13);
        Writer output13= new BufferedWriter(fw13);
        int sz13=userDetails13.size();
        for(int i=0;i<sz13;i++){
            output13.write(userDetails13.get(i).toString()+"\n");
        }
        output13.close();
    }catch (Exception e){
        System.out.println("13th seat is empty");
    }
try{
        File fileName14=new File("User14");
        FileWriter fw14=new FileWriter(fileName14);
        Writer output14= new BufferedWriter(fw14);
        int sz14=userDetails14.size();
        for(int i=0;i<sz14;i++){
            output14.write(userDetails14.get(i).toString()+"\n");
        }
        output14.close();
    }catch (Exception e){
        System.out.println("14th seat is empty");
    }
try{
        File fileName15=new File("User15");
        FileWriter fw15=new FileWriter(fileName15);
        Writer output15= new BufferedWriter(fw15);
        int sz15=userDetails15.size();
        for(int i=0;i<sz15;i++){
            output15.write(userDetails15.get(i).toString()+"\n");
        }
        output15.close();
    }catch (Exception e){
        System.out.println("15th seat is empty");
    }
try{
        File fileName16=new File("User16");
        FileWriter fw16=new FileWriter(fileName16);
        Writer output16= new BufferedWriter(fw16);
        int sz16=userDetails16.size();
        for(int i=0;i<sz16;i++){
            output16.write(userDetails16.get(i).toString()+"\n");
        }
        output16.close();
    }catch (Exception e){
        System.out.println("16th seat is empty");
    }
try{
        File fileName17=new File("User17");
        FileWriter fw17=new FileWriter(fileName17);
        Writer output17= new BufferedWriter(fw17);
        int sz17=userDetails17.size();
        for(int i=0;i<sz17;i++){
            output17.write(userDetails17.get(i).toString()+"\n");
        }
        output17.close();
    }catch (Exception e){
        System.out.println("17th seat is empty");
    }
try{
        File fileName18=new File("User18");
        FileWriter fw18=new FileWriter(fileName18);
        Writer output18= new BufferedWriter(fw18);
        int sz18=userDetails18.size();
        for(int i=0;i<sz18;i++){
            output18.write(userDetails18.get(i).toString()+"\n");
        }
        output18.close();
    }catch (Exception e){
        System.out.println("18th seat is empty");
    }
try{
        File fileName19=new File("User19");
        FileWriter fw19=new FileWriter(fileName19);
        Writer output19= new BufferedWriter(fw19);
        int sz19=userDetails19.size();
        for(int i=0;i<sz19;i++){
            output19.write(userDetails19.get(i).toString()+"\n");
        }
        output19.close();
    }catch (Exception e){
        System.out.println("19th seat is empty");
    }
try{
        File fileName20=new File("User20");
        FileWriter fw20=new FileWriter(fileName20);
        Writer output20= new BufferedWriter(fw20);
        int sz20=userDetails20.size();
        for(int i=0;i<sz20;i++){
            output20.write(userDetails20.get(i).toString()+"\n");
        }
        output20.close();
    }catch (Exception e){
        System.out.println("20th seat is empty");
    }
try{
        File fileName21=new File("User21");
        FileWriter fw21=new FileWriter(fileName21);
        Writer output21= new BufferedWriter(fw21);
        int sz21=userDetails21.size();
        for(int i=0;i<sz21;i++){
            output21.write(userDetails21.get(i).toString()+"\n");
        }
        output21.close();
    }catch (Exception e){
        System.out.println("21st seat is empty");
    }
try{
        File fileName22=new File("User22");
        FileWriter fw22=new FileWriter(fileName22);
        Writer output22= new BufferedWriter(fw22);
        int sz22=userDetails22.size();
        for(int i=0;i<sz22;i++){
            output22.write(userDetails22.get(i).toString()+"\n");
        }
        output22.close();
    }catch (Exception e){
        System.out.println("22nd seat is empty");
    }
try{
        File fileName23=new File("User23");
        FileWriter fw23=new FileWriter(fileName23);
        Writer output23= new BufferedWriter(fw23);
        int sz23=userDetails23.size();
        for(int i=0;i<sz23;i++){
            output23.write(userDetails23.get(i).toString()+"\n");
        }
        output23.close();
    }catch (Exception e){
        System.out.println("23rd seat is empty");
    }
try{
        File fileName24=new File("User24");
        FileWriter fw24=new FileWriter(fileName24);
        Writer output24= new BufferedWriter(fw24);
        int sz24=userDetails24.size();
        for(int i=0;i<sz24;i++){
            output24.write(userDetails24.get(i).toString()+"\n");
        }
        output24.close();
    }catch (Exception e){
        System.out.println("24th seat is empty");
    }
try{
        File fileName25=new File("User25");
        FileWriter fw25=new FileWriter(fileName25);
        Writer output25= new BufferedWriter(fw25);
        int sz25=userDetails25.size();
        for(int i=0;i<sz25;i++){
            output25.write(userDetails25.get(i).toString()+"\n");
        }
        output25.close();
    }catch (Exception e){
        System.out.println("25th seat is empty");
    }
try{
        File fileName26=new File("User26");
        FileWriter fw26=new FileWriter(fileName26);
        Writer output26= new BufferedWriter(fw26);
        int sz26=userDetails26.size();
        for(int i=0;i<sz26;i++){
            output26.write(userDetails26.get(i).toString()+"\n");
        }
        output26.close();
    }catch (Exception e){
        System.out.println("26th seat is empty");
    }
try{
        File fileName27=new File("User27");
        FileWriter fw27=new FileWriter(fileName27);
        Writer output27= new BufferedWriter(fw27);
        int sz27=userDetails27.size();
        for(int i=0;i<sz27;i++){
            output27.write(userDetails27.get(i).toString()+"\n");
        }
        output27.close();
    }catch (Exception e){
        System.out.println("27th seat is empty");
    }
try{
        File fileName28=new File("User28");
        FileWriter fw28=new FileWriter(fileName28);
        Writer output28= new BufferedWriter(fw28);
        int sz28=userDetails28.size();
        for(int i=0;i<sz28;i++){
            output28.write(userDetails28.get(i).toString()+"\n");
        }
        output28.close();
    }catch (Exception e){
        System.out.println("28th seat is empty");
    }
try{
        File fileName29=new File("User29");
        FileWriter fw29=new FileWriter(fileName29);
        Writer output29= new BufferedWriter(fw29);
        int sz29=userDetails29.size();
        for(int i=0;i<sz29;i++){
            output29.write(userDetails29.get(i).toString()+"\n");
        }
        output29.close();
    }catch (Exception e){
        System.out.println("29th seat is empty");
    }
try{
        File fileName30=new File("User30");
        FileWriter fw30=new FileWriter(fileName30);
        Writer output30= new BufferedWriter(fw30);
        int sz30=userDetails30.size();
        for(int i=0;i<sz30;i++){
            output30.write(userDetails30.get(i).toString()+"\n");
        }
        output30.close();
    }catch (Exception e){
        System.out.println("30th seat is empty");
    }
try{
        File fileName31=new File("User31");
        FileWriter fw31=new FileWriter(fileName31);
        Writer output31= new BufferedWriter(fw31);
        int sz31=userDetails31.size();
        for(int i=0;i<sz31;i++){
            output31.write(userDetails31.get(i).toString()+"\n");
        }
        output31.close();
    }catch (Exception e){
        System.out.println("31st seat is empty");
    }
try{
        File fileName32=new File("User32");
        FileWriter fw32=new FileWriter(fileName32);
        Writer output32= new BufferedWriter(fw32);
        int sz32=userDetails32.size();
        for(int i=0;i<sz32;i++){
            output32.write(userDetails32.get(i).toString()+"\n");
        }
        output32.close();
    }catch (Exception e){
        System.out.println("32nd seat is empty");
    }
try{
        File fileName33=new File("User33");
        FileWriter fw33=new FileWriter(fileName33);
        Writer output33= new BufferedWriter(fw33);
        int sz33=userDetails33.size();
        for(int i=0;i<sz33;i++){
            output33.write(userDetails33.get(i).toString()+"\n");
        }
        output33.close();
    }catch (Exception e){
        System.out.println("33rd seat is empty");
    }
try{
        File fileName34=new File("User34");
        FileWriter fw34=new FileWriter(fileName34);
        Writer output34= new BufferedWriter(fw34);
        int sz34=userDetails34.size();
        for(int i=0;i<sz34;i++){
            output34.write(userDetails34.get(i).toString()+"\n");
        }
        output34.close();
    }catch (Exception e){
        System.out.println("34th seat is empty");
    }
try{
        File fileName35=new File("User35");
        FileWriter fw35=new FileWriter(fileName35);
        Writer output35= new BufferedWriter(fw35);
        int sz35=userDetails35.size();
        for(int i=0;i<sz35;i++){
            output35.write(userDetails35.get(i).toString()+"\n");
        }
        output35.close();
    }catch (Exception e){
        System.out.println("35th seat is empty");
    }
try{
        File fileName36=new File("User36");
        FileWriter fw36=new FileWriter(fileName36);
        Writer output36= new BufferedWriter(fw36);
        int sz36=userDetails36.size();
        for(int i=0;i<sz36;i++){
            output36.write(userDetails36.get(i).toString()+"\n");
        }
        output36.close();
    }catch (Exception e){
        System.out.println("36th seat is empty");
    }
try{
        File fileName37=new File("User37");
        FileWriter fw37=new FileWriter(fileName37);
        Writer output37= new BufferedWriter(fw37);
        int sz37=userDetails37.size();
        for(int i=0;i<sz37;i++){
            output37.write(userDetails37.get(i).toString()+"\n");
        }
        output37.close();
    }catch (Exception e){
        System.out.println("37th seat is empty");
    }
try{
        File fileName38=new File("User38");
        FileWriter fw38=new FileWriter(fileName38);
        Writer output38= new BufferedWriter(fw38);
        int sz38=userDetails38.size();
        for(int i=0;i<sz38;i++){
            output38.write(userDetails38.get(i).toString()+"\n");
        }
        output38.close();
    }catch (Exception e){
        System.out.println("38th seat is empty");
    }
try{
        File fileName39=new File("User39");
        FileWriter fw39=new FileWriter(fileName39);
        Writer output39= new BufferedWriter(fw39);
        int sz39=userDetails39.size();
        for(int i=0;i<sz39;i++){
            output39.write(userDetails39.get(i).toString()+"\n");
        }
        output39.close();
    }catch (Exception e){
        System.out.println("39th seat is empty");
    }
try{
        File fileName40=new File("User40");
        FileWriter fw40=new FileWriter(fileName40);
        Writer output40= new BufferedWriter(fw40);
        int sz40=userDetails40.size();
        for(int i=0;i<sz40;i++){
            output40.write(userDetails40.get(i).toString()+"\n");
        }
        output40.close();
    }catch (Exception e){
        System.out.println("40th seat is empty");
    }
try{
        File fileName41=new File("User41");
        FileWriter fw41=new FileWriter(fileName41);
        Writer output41= new BufferedWriter(fw41);
        int sz41=userDetails41.size();
        for(int i=0;i<sz41;i++){
            output41.write(userDetails41.get(i).toString()+"\n");
        }
        output41.close();
    }catch (Exception e){
        System.out.println("41st seat is empty");
    }
try{
        File fileName42=new File("User42");
        FileWriter fw42=new FileWriter(fileName42);
        Writer output42= new BufferedWriter(fw42);
        int sz42=userDetails42.size();
        for(int i=0;i<sz42;i++){
            output42.write(userDetails42.get(i).toString()+"\n");
        }
        output42.close();
    }catch (Exception e){
        System.out.println("42th seat is empty");
    }

    }

    private static void load() {
    }

    public static void main(String[] args)  {
        launch(args);
    }
}